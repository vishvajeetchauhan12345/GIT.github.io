﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Models
{
    public class User
    {
        public int Id { get; set; }
        [Required]
        [MinLength(20)]
        [MaxLength(30)]
        public string Name { get; set; }
        [Required]
        [MinLength(4)]
        [MaxLength(10)]
        public string Gender { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        [MinLength(10)]
        [MaxLength(10)]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid Phone number")]
        public string Contact { get; set; }
        [Required]
        public string Image { get; set; }
        [Required]
        public string IsActive { get; set; }
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        [Compare("Password",ErrorMessage ="Password not match!")]
        public string ConfirmPassword { get; set; }
    }
}
