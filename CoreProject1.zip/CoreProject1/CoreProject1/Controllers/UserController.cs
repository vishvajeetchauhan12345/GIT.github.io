﻿using CoreProject1.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Controllers
{
    public class UserController : Controller
    {
        private AppDbContext dbcon;
        private readonly IHostingEnvironment Environment;

        public UserController(AppDbContext conn,IHostingEnvironment environment) 
        {
            dbcon = conn;
            Environment = environment;
        }
        [HttpGet]
       /* public IActionResult Index()
        {
            var list = dbcon.users.ToList();
            return View(list);
        }*/
        public IActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Registration(User user)
        {
            var files = Request.Form.Files;
            string dbpath = string.Empty;
            if (files.Count > 0) 
            {
                string path = Environment.WebRootPath;
                string fullpath = Path.Combine(path,"images",files[0].FileName);
                dbpath = "images/" + files[0].FileName;
                FileStream stream = new FileStream(fullpath,FileMode.Create);
                files[0].CopyTo(stream);
            }
            user.Image = dbpath;
            dbcon.users.Add(user);
            dbcon.SaveChanges();
            return RedirectToAction("Index","User");
        }
    }
}
